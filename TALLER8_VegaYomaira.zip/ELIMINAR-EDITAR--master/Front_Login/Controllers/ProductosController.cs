﻿using Front_Login.Models;
using Microsoft.AspNetCore.Mvc;
using System.Net.Http;
using System.Net.Http.Json; 
using System.Text.Json; 

namespace Front_Login.Controllers
{
    public class ProductosController : Controller
    {
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly string _apiUrl = "http://localhost:8080/api/productos"; // URL base de tu API de productos

        public ProductosController(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }

        
        public IActionResult Index()
        {
            return View(); // Simplemente muestra la página HTML principal
        }

        [HttpGet]
        public async Task<IActionResult> Listar()
        {
            try
            {
                var client = _httpClientFactory.CreateClient();
                var productos = await client.GetFromJsonAsync<List<Producto>>(_apiUrl);
                return Json(new { data = productos ?? new List<Producto>() }); 
            }
            catch (HttpRequestException)
            {
                return StatusCode(503, "API no disponible"); // Service Unavailable
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error interno: {ex.Message}");
            }
        }

        // GET: /Productos/ObtenerPorId/{id} (Devuelve un producto específico en JSON)
        [HttpGet]
        public async Task<IActionResult> ObtenerPorId(long id)
        {
            try
            {
                var client = _httpClientFactory.CreateClient();
                var producto = await client.GetFromJsonAsync<Producto>($"{_apiUrl}/{id}");
                if (producto == null)
                {
                    return NotFound();
                }
                return Json(producto);
            }
            catch (HttpRequestException)
            {
                return StatusCode(503, "API no disponible");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error interno: {ex.Message}");
            }
        }


        // POST: /Productos/Guardar (Crea o actualiza un producto)
        [HttpPost]
        public async Task<IActionResult> Guardar([FromBody] Producto producto) // [FromBody] es clave para recibir JSON
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                var client = _httpClientFactory.CreateClient();
                HttpResponseMessage response;

                if (producto.IdProducto == 0) // Si el ID es 0, es un nuevo producto (POST)
                {
                    response = await client.PostAsJsonAsync(_apiUrl, producto);
                }
                else // Si el ID no es 0, es una actualización (PUT)
                {
                    response = await client.PutAsJsonAsync($"{_apiUrl}/{producto.IdProducto}", producto);
                }

                if (response.IsSuccessStatusCode)
                {
                    // Puedes devolver el producto creado/actualizado si la API lo retorna
                    var productoGuardado = await response.Content.ReadFromJsonAsync<Producto>();
                    return Ok(productoGuardado); // O simplemente return Ok();
                }
                else
                {
                    var errorContent = await response.Content.ReadAsStringAsync();
                    return StatusCode((int)response.StatusCode, $"Error de API: {errorContent}");
                }
            }
            catch (HttpRequestException)
            {
                return StatusCode(503, "API no disponible");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error interno: {ex.Message}");
            }
        }

        // DELETE: /Productos/Eliminar/{id}
        [HttpDelete]
        public async Task<IActionResult> Eliminar(long id)
        {
            if (id <= 0)
            {
                return BadRequest("ID de producto inválido.");
            }
            try
            {
                var client = _httpClientFactory.CreateClient();
                var response = await client.DeleteAsync($"{_apiUrl}/{id}");

                if (response.IsSuccessStatusCode)
                {
                    return Ok(new { message = "Producto eliminado correctamente." }); // Éxito
                }
                else if (response.StatusCode == System.Net.HttpStatusCode.NotFound)
                {
                    return NotFound("Producto no encontrado.");
                }
                else
                {
                    var errorContent = await response.Content.ReadAsStringAsync();
                    return StatusCode((int)response.StatusCode, $"Error de API al eliminar: {errorContent}");
                }
            }
            catch (HttpRequestException)
            {
                return StatusCode(503, "API no disponible");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error interno: {ex.Message}");
            }
        }
    }
}