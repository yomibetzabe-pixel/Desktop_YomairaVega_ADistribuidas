﻿using Front_Login.Models;
using Microsoft.AspNetCore.Mvc;
using System.Net.Http.Json; // Required for ReadFromJsonAsync and PostAsJsonAsync

namespace Front_Login.Controllers
{
    // Helper class to read the JSON response from your Spring Boot API
    // It should match the fields returned by your API upon successful login.
    public class UserResponse
    {
        public string Nombre { get; set; }
        // You can add more properties here if your API returns them, e.g., Email, IdUsuario
    }

    public class LoginController : Controller
    {
        private readonly IHttpClientFactory _httpClientFactory;

        // The constructor receives the IHttpClientFactory via dependency injection.
        // This is the modern way to handle HTTP requests in ASP.NET Core.
        public LoginController(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }

        // GET: /Login
        // This action simply displays the login form view.
        public IActionResult Index()
        {
            return View();
        }

        // POST: /Login
        // This action is triggered when the user submits the login form.
        [HttpPost]
        public async Task<IActionResult> Index(LoginRequest model)
        {
            // First, check if the form fields (Email, Password) are valid based on the annotations in LoginRequest.cs.
            if (!ModelState.IsValid)
            {
                return View(model); // If not, show the form again with validation errors.
            }

            // Create an HttpClient to make the call to the API.
            var client = _httpClientFactory.CreateClient();
            var apiUrl = "http://localhost:8080/api/login"; // Your Spring Boot login endpoint URL.

            try
            {
                // Send the login data (model) as JSON to your Spring Boot API.
                var response = await client.PostAsJsonAsync(apiUrl, model);

                // Check if the API responded with a success code (e.g., 200 OK).
                if (response.IsSuccessStatusCode)
                {
                    // Login successful! 🎉
                    // Read the user data from the API's JSON response.
                    var user = await response.Content.ReadFromJsonAsync<UserResponse>();

                    // Store the user's name in TempData. TempData is a temporary storage
                    // that persists for one redirect, perfect for this scenario.
                    TempData["UserName"] = user.Nombre;

                    // Redirect the user to the Home page.
                    return RedirectToAction("Index", "Home");
                }
                else
                {
                    // The API responded with an error (e.g., 401 Unauthorized).
                    // This means the credentials were wrong.
                    ModelState.AddModelError(string.Empty, "Usuario o contraseña incorrectos.");
                }
            }
            catch (HttpRequestException)
            {
                // This catch block is executed if the API is down or unreachable.
                ModelState.AddModelError(string.Empty, "Error de conexión: El servidor no responde.");
            }

            // If we reach this point, it means the login failed for some reason.
            // Return the view so the user can see the error message.
            return View(model);
        }
    }
}