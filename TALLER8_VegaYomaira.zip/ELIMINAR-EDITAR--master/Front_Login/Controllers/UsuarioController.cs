﻿using Front_Login.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;

namespace Front_Login.Controllers
{
    public class UsuarioController : Controller
    {
        private readonly IHttpClientFactory _httpClientFactory;

        public UsuarioController(IHttpClientFactory httpClientFactory)
        {
            _httpClientFactory = httpClientFactory;
        }

        public async Task<IActionResult> Index()
        {
            List<UsuarioViewModel> usuarios = new List<UsuarioViewModel>();
            var client = _httpClientFactory.CreateClient();
            var response = await client.GetAsync("http://localhost:8080/api/usuarios");
            if (response.IsSuccessStatusCode)
            {
                var jsonResponse = await response.Content.ReadAsStringAsync();
                usuarios = JsonConvert.DeserializeObject<List<UsuarioViewModel>>(jsonResponse);
            }
            return View(usuarios);
        }

        // GET: /Usuario/Crear
        public async Task<IActionResult> Crear()
        {
            await PopulateRolesViewBag();
            return View();
        }

        // POST: /Usuario/Crear
        [HttpPost]
        public async Task<IActionResult> Crear(UsuarioCreateModel usuario)
        {
            if (ModelState.IsValid)
            {
                var client = _httpClientFactory.CreateClient();
                var jsonContent = JsonConvert.SerializeObject(usuario);
                var content = new StringContent(jsonContent, System.Text.Encoding.UTF8, "application/json");
                var response = await client.PostAsync("http://localhost:8080/api/usuarios", content);

                if (response.IsSuccessStatusCode)
                {
                    TempData["Exito"] = "Usuario creado con éxito";
                    return RedirectToAction(nameof(Index));
                }
                ModelState.AddModelError(string.Empty, "Ocurrió un error al crear el usuario.");
            }

            await PopulateRolesViewBag();
            return View(usuario);
        }

        // GET: /Usuario/Editar/5
        public async Task<IActionResult> Editar(long id)
        {
            var client = _httpClientFactory.CreateClient();
            var response = await client.GetAsync($"http://localhost:8080/api/usuarios/{id}");

            if (!response.IsSuccessStatusCode)
            {
                return RedirectToAction(nameof(Index));
            }

            var jsonResponse = await response.Content.ReadAsStringAsync();
            var usuarioToEdit = JsonConvert.DeserializeObject<UsuarioCreateModel>(jsonResponse);

            await PopulateRolesViewBag();

            // La corrección probablemente está aquí. Se debe retornar la variable, no el tipo.
            return View(usuarioToEdit);
        }

        // POST: /Usuario/Editar/5
        [HttpPost]
        public async Task<IActionResult> Editar(long id, UsuarioCreateModel usuario)
        {
            if (ModelState.IsValid)
            {
                var client = _httpClientFactory.CreateClient();
                var jsonContent = JsonConvert.SerializeObject(usuario);
                var content = new StringContent(jsonContent, System.Text.Encoding.UTF8, "application/json");
                var response = await client.PutAsync($"http://localhost:8080/api/usuarios/{id}", content);

                if (response.IsSuccessStatusCode)
                {
                    TempData["Exito"] = "Usuario actualizado con éxito";
                    return RedirectToAction(nameof(Index));
                }
                ModelState.AddModelError(string.Empty, "Ocurrió un error al actualizar.");
            }

            await PopulateRolesViewBag();
            return View(usuario);
        }

        private async Task PopulateRolesViewBag()
        {
            var client = _httpClientFactory.CreateClient();
            var response = await client.GetAsync("http://localhost:8080/api/roles");
            if (response.IsSuccessStatusCode)
            {
                var jsonResponse = await response.Content.ReadAsStringAsync();
                ViewBag.Roles = JsonConvert.DeserializeObject<List<RolViewModel>>(jsonResponse);
            }
            else
            {
                ViewBag.Roles = new List<RolViewModel>();
            }
        }
    }
}