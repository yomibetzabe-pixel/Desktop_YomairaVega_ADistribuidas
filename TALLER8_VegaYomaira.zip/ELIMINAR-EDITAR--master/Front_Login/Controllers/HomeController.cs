﻿using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace Front_Login.Controllers
{
    public class HomeController : Controller
    {
        // Esta acción se ejecuta cuando la URL es /Home o /Home/Index
        public IActionResult Index()
        {
            return View();
        }

        // Esta acción maneja la página de privacidad
        public IActionResult Privacy()
        {
            return View();
        }
    }
}