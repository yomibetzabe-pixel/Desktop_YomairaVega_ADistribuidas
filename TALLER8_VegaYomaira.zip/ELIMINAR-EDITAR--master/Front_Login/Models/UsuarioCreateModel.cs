﻿namespace Front_Login.Models
{
    public class UsuarioCreateModel
    {
        // No usamos JsonProperty, forzamos los nombres directamente
        public string nombre { get; set; } = string.Empty;
        public string email { get; set; } = string.Empty;
        public string contrasena { get; set; } = string.Empty; 
        public RolSelectionModel rol { get; set; } = new RolSelectionModel();
    }

    public class RolSelectionModel
    {
        public int idRol { get; set; }
    }
}