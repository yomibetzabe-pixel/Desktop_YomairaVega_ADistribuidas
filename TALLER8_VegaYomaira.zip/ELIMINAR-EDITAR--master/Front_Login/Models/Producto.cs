﻿using System.ComponentModel.DataAnnotations;

namespace Front_Login.Models
{
    public class Producto
    {
        public long IdProducto { get; set; } // O el nombre del ID que use tu API (id, productoId, etc.)

        [Required(ErrorMessage = "El nombre es obligatorio")]
        public string Nombre { get; set; }

        public string Descripcion { get; set; } // Opcional

        [Required(ErrorMessage = "El precio es obligatorio")]
        [Range(0.01, double.MaxValue, ErrorMessage = "El precio debe ser mayor a 0")]
        public decimal Precio { get; set; }

        // Puedes agregar más campos si tu API los tiene (ej: stock, categoriaId, etc.)
    }
}