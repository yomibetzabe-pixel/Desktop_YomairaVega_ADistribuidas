﻿using System.ComponentModel.DataAnnotations;

namespace Front_Login.Models
{
    public class LoginRequest
    {
        [Required(ErrorMessage = "Por favor, ingrese su correo electrónico.")]
        [EmailAddress(ErrorMessage = "El formato del correo no es válido.")]
        public string Email { get; set; }

        // CAMBIO CLAVE: Renombramos "Password" a "Contrasena"
        [Required(ErrorMessage = "Por favor, ingrese su contraseña.")]
        public string Contrasena { get; set; }
    }
}