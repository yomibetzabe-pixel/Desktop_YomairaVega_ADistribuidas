﻿using Newtonsoft.Json;

namespace Front_Login.Models
{
    public class RolViewModel
    {
        [JsonProperty("idRol")]
        public int IdRol { get; set; }

        [JsonProperty("nombreRol")]
        public string NombreRol { get; set; } = string.Empty; // Valor inicial
    }
}