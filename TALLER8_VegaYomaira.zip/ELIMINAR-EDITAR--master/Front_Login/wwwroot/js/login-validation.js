﻿// --- VARIABLES GLOBALES ---
// Leemos los intentos fallidos guardados en la sesión del navegador.
let failedAttempts = parseInt(sessionStorage.getItem("failedLoginAttempts")) || 0;
const maxAttempts = 3;
const lockoutTime = 30000; // 30 segundos en milisegundos

/**
 * Esta función es llamada desde la vista cuando el servidor devuelve un error de credenciales.
 * Debe estar en el scope global (window) para ser accesible.
 */
window.handleFailedLogin = function () {
    failedAttempts++;
    sessionStorage.setItem("failedLoginAttempts", failedAttempts);

    if (failedAttempts >= maxAttempts) {
        lockButton();
    }
};

/**
 * Desactiva el botón de login y muestra un mensaje de espera.
 */
function lockButton() {
    const loginButton = document.getElementById("loginButton");
    if (loginButton) {
        loginButton.disabled = true;
        loginButton.textContent = `Demasiados intentos. Espere 30 segundos...`;

        // Temporizador para reactivar el botón
        setTimeout(function () {
            failedAttempts = 0;
            sessionStorage.setItem("failedLoginAttempts", failedAttempts);
            loginButton.disabled = false;
            loginButton.textContent = "Iniciar Sesión";
        }, lockoutTime);
    }
}

/**
 * El código que necesita interactuar con los elementos del formulario (DOM)
 * se queda dentro de este listener para asegurar que la página ya cargó.
 */
document.addEventListener("DOMContentLoaded", function () {
    const loginForm = document.getElementById("loginForm");
    const loginButton = document.getElementById("loginButton");

    if (loginForm && loginButton) {
        loginForm.addEventListener("submit", function (event) {
            // Previene que el usuario envíe el formulario si el botón está bloqueado.
            if (loginButton.disabled) {
                event.preventDefault();
            }
        });
    }
}); 