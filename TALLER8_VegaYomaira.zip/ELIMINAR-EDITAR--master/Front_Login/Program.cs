var builder = WebApplication.CreateBuilder(args);

// Agrega los servicios necesarios para que funcionen los Controladores y las Vistas (MVC).
builder.Services.AddControllersWithViews();
builder.Services.AddHttpClient();

var app = builder.Build();

// Configura el pipeline de peticiones HTTP.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // Activa HSTS para mayor seguridad en producci�n.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles(); // Permite que la app use archivos CSS, JavaScript, etc. de la carpeta wwwroot.

app.UseRouting(); // Activa el sistema de enrutamiento.

app.UseAuthorization();

// ESTA ES LA REGLA DE ENRUTAMIENTO CLAVE.
// Le dice a la aplicaci�n c�mo interpretar las URLs.
// "{controller=Home}/{action=Index}/{id?}" significa:
// 1. La primera parte de la URL es el nombre del Controlador (ej: "Login").
// 2. La segunda parte es el nombre del M�todo/Acci�n (ej: "Index").
// 3. Si no se especifica nada, usa "Home" como controlador y "Index" como acci�n.
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Login}/{action=Index}/{id?}");

app.Run();