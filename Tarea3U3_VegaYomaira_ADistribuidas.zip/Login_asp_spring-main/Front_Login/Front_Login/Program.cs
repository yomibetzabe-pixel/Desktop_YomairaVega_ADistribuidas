﻿var builder = WebApplication.CreateBuilder(args);

// 🔧 Servicios disponibles para la app
builder.Services.AddControllersWithViews(); // MVC
builder.Services.AddHttpClient(); // Cliente HTTP para consumir APIs

// 🧠 Servicios de sesión
builder.Services.AddDistributedMemoryCache(); // Requerido para sesiones
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(30); // Tiempo de expiración
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
});

var app = builder.Build();

// 🛠️ Configuración del pipeline HTTP
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error"); // Página de error en producción
}

app.UseStaticFiles(); // Archivos estáticos (CSS, JS, imágenes)
app.UseRouting();     // Habilita el enrutamiento
app.UseSession();     // ✅ Mueve esto antes de Authorization
app.UseAuthorization(); // Si usas roles/autenticación

// 🚪 Ruta predeterminada: inicia en Login
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Login}/{action=Index}/{id?}");

app.Run();

