﻿using System.Text;
using System.Threading.Tasks;
using Front_Login.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace Front_Login.Controllers
{
    public class LoginController : Controller
    {
        private readonly HttpClient _httpClient;

        public LoginController(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Login(LoginRequest model)
        {
            if (!ModelState.IsValid)
            {
                TempData["Error"] = "Por favor completa todos los campos correctamente.";
                return View("Index");
            }

            var jsonContent = JsonConvert.SerializeObject(model);
            var content = new StringContent(jsonContent, Encoding.UTF8, "application/json");

            try
            {
                var response = await _httpClient.PostAsync("http://localhost:8080/api/login", content);

                if (response.IsSuccessStatusCode)
                {
                    var jsonResponse = await response.Content.ReadAsStringAsync();
                    var usuario = JsonConvert.DeserializeObject<Usuario>(jsonResponse);

                    if (usuario != null)
                    {
                        HttpContext.Session.SetString("Usuario", JsonConvert.SerializeObject(usuario));
                        return RedirectToAction("Index", "Home");
                    }
                    else
                    {
                        TempData["Error"] = "Usuario o contraseña incorrectos.";
                        return View("Index");
                    }
                }
                else
                {
                    TempData["Error"] = "Usuario o contraseña incorrectos.";
                    return View("Index");
                }
            }
            catch (Exception ex)
            {
                TempData["Error"] = $"Error inesperado: {ex.Message}";
                return View("Index");
            }
        }
    }
}