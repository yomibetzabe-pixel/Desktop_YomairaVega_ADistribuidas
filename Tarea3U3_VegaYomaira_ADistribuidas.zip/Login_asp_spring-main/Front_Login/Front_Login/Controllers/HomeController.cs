﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Front_Login.Models;
using Newtonsoft.Json;

namespace Front_Login.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }

    public IActionResult Index()
    {
        var usuarioJson = HttpContext.Session.GetString("Usuario");
        Console.WriteLine("Contenido de sesión: " + usuarioJson);

        if (string.IsNullOrEmpty(usuarioJson))
        {
            TempData["Error"] = "No hay sesión activa. Por favor inicia sesión.";
            return RedirectToAction("Index", "Login");
        }

        var usuario = JsonConvert.DeserializeObject<Usuario>(usuarioJson);

        ViewBag.Nombre = usuario?.NombreUsuario ?? "Usuario";

        return View();
    }

    public IActionResult Privacy()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}