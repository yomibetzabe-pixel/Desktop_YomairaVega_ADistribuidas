package com.denm.salud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SaludApplicationTests {

	@Test
	void contextLoads() {
	}

}
