package com.denm.salud.controlador;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.denm.salud.modelo.entidad.Especialidad;
import com.denm.salud.servicio.IEspecialidadServicio;

@RestController
@RequestMapping("api/especialidad")
public class EspecialidadControlador {
	
	@Autowired
	private IEspecialidadServicio servicio;
	
	@GetMapping
	public List<Especialidad> listarEspecialidad(){
		return servicio.listarEspecialidad();
	}
	
	@PostMapping
	public Especialidad insertarEspecialidad(@RequestBody Especialidad especialidad) {
		return servicio.insertarEspecialidad(especialidad);
	}
	
	@GetMapping("/{id}")
	public Especialidad editarEspecialidad(@PathVariable int id) {
		return servicio.editarEspecialidad(id);
	}
	
	@DeleteMapping("/{id}")
	public void eliminarEspecialidad(@PathVariable int id) {
		servicio.eliminarEspecialidad(id);
	}

}
