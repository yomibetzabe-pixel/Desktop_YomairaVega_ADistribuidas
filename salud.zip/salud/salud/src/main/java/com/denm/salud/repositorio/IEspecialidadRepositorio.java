package com.denm.salud.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.denm.salud.modelo.entidad.Especialidad;

@Component
@Repository
public interface IEspecialidadRepositorio extends JpaRepository<Especialidad, Integer>{

}
