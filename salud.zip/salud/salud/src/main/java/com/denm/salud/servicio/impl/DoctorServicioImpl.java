package com.denm.salud.servicio.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.denm.salud.modelo.entidad.Doctor;
import com.denm.salud.repositorio.IDoctorRepositorio;
import com.denm.salud.servicio.IDoctorServicio;

@Service
@Component
public class DoctorServicioImpl implements IDoctorServicio{
	
	@Autowired
	private IDoctorRepositorio repositorio;

	@Override
	public Doctor insertarDoctor(Doctor doctor) {
	    if (doctor.getFkIdEspecialidad() == null || doctor.getFkIdEspecialidad().getIdEspecialidad() == 0) {
	        throw new IllegalArgumentException("Especialidad no válida");
	    }
	    return repositorio.save(doctor);
	}

	@Override
	public Doctor editarDoctor(int idDoctor) {
	    return repositorio.findById(idDoctor).orElse(null);
	}

	@Override
	public void eliminarDoctor(int idDoctor) {
		// TODO Auto-generated method stub
		repositorio.delete(editarDoctor(idDoctor));
	}

	@Override
	public List<Doctor> listarDoctor() {
		// TODO Auto-generated method stub
		return repositorio.findAll();
	}
}
