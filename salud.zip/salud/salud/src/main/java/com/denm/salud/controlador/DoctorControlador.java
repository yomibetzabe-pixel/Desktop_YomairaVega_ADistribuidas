package com.denm.salud.controlador;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.denm.salud.modelo.entidad.Doctor;
import com.denm.salud.modelo.entidad.Especialidad;
import com.denm.salud.servicio.IDoctorServicio;
import com.denm.salud.servicio.IEspecialidadServicio;

@RestController
@RequestMapping("api/doctor")
public class DoctorControlador {

    @Autowired
    private IDoctorServicio servicio;

    @Autowired
    private IEspecialidadServicio servicioEspecialidad;

    // ✅ Listar todos los doctores
    @GetMapping
    public List<Doctor> listarDoctor() {
        return servicio.listarDoctor();
    }

    // ✅ Insertar un nuevo doctor con validación
    @PostMapping
    public ResponseEntity<?> insertarDoctor(@RequestBody Doctor doctor) {
        try {
            if (doctor.getFkIdEspecialidad() == null || doctor.getFkIdEspecialidad().getIdEspecialidad() <= 0) {
                return ResponseEntity.badRequest().body("La especialidad es obligatoria");
            }

            Especialidad especialidad = servicioEspecialidad.editarEspecialidad(
                    doctor.getFkIdEspecialidad().getIdEspecialidad());

            if (especialidad == null) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body("La especialidad con ID " + doctor.getFkIdEspecialidad().getIdEspecialidad() + " no existe");
            }

            doctor.setFkIdEspecialidad(especialidad);
            Doctor nuevoDoctor = servicio.insertarDoctor(doctor);
            return ResponseEntity.ok(nuevoDoctor);

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error interno: " + e.getMessage());
        }
    }

    // ✅ Obtener un doctor por ID
    @GetMapping("/{id}")
    public ResponseEntity<?> editarDoctor(@PathVariable int id) {
        try {
            Doctor doctor = servicio.editarDoctor(id);

            if (doctor == null) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body("Doctor no encontrado");
            }

            return ResponseEntity.ok(doctor);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error al obtener el doctor: " + e.getMessage());
        }
    }
    // ✅ Eliminar un doctor por ID
    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminarDoctor(@PathVariable int id) {
        try {
            servicio.eliminarDoctor(id);
            return ResponseEntity.ok("Doctor eliminado correctamente");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error al eliminar el doctor: " + e.getMessage());
        }
    }
}