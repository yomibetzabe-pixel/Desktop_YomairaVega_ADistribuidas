package com.denm.salud.servicio;

import java.util.List;

import com.denm.salud.modelo.entidad.Especialidad;


public interface IEspecialidadServicio {
	
	public Especialidad insertarEspecialidad(Especialidad especialidad);
	public Especialidad editarEspecialidad(int idEspecialidad);
	public void eliminarEspecialidad(int idEspecialidad);
	public List<Especialidad> listarEspecialidad();

}
