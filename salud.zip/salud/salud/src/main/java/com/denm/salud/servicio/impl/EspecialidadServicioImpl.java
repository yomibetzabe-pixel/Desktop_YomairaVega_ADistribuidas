package com.denm.salud.servicio.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.denm.salud.modelo.entidad.Especialidad;
import com.denm.salud.repositorio.IEspecialidadRepositorio;
import com.denm.salud.servicio.IEspecialidadServicio;

@Service
@Component
public class EspecialidadServicioImpl implements IEspecialidadServicio{
	
	@Autowired
	private IEspecialidadRepositorio repositorio;

	@Override
	public Especialidad insertarEspecialidad(Especialidad especialidad) {
		// TODO Auto-generated method stub
		return repositorio.save(especialidad);
	}

	@Override
	public Especialidad editarEspecialidad(int idEspecialidad) {
		// TODO Auto-generated method stub
		return repositorio.findById(idEspecialidad).get();
	}

	@Override
	public void eliminarEspecialidad(int idEspecialidad) {
		// TODO Auto-generated method stub
		repositorio.delete(editarEspecialidad(idEspecialidad));
	}

	@Override
	public List<Especialidad> listarEspecialidad() {
		// TODO Auto-generated method stub
		return repositorio.findAll();
	}

}
