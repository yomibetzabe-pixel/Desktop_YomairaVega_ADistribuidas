
import React, { useEffect, useState } from 'react';
import { ScrollView, View, Text, StyleSheet, ActivityIndicator, Alert } from 'react-native';
import * as FileSystem from 'expo-file-system';
import { Image } from 'expo-image';
import { Audio, Video } from 'expo-av';

// URLs temáticas (deporte, gastronomía, librería)
const REMOTE_IMAGES = {
  deporte: 'https://images.unsplash.com/photo-1517649763962-0c623066013b?q=80&w=1080&auto=format&fit=crop',
  gastronomia: 'https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.pinterest.com%2Fjoipaz7%2Fencebollado%2F&psig=AOvVaw330gBUvea4hrsWTxZgxWod&ust=1758382329181000&source=images&cd=vfe&opi=89978449&ved=0CBIQjRxqFwoTCJiOsuqS5Y8DFQAAAAAdAAAAABAE',
  libreria: 'https://ateneatours.com/wp-content/uploads/2023/02/Biblioteca-Nacional-de-Grecia.jpg',
};

// MP4 público (demo). 
const REMOTE_VIDEO_MP4 =
  'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4';

// Preferir documentDirectory; fallback a cacheDirectory (útil para web)
const DOC_DIR = FileSystem.documentDirectory ?? FileSystem.cacheDirectory ?? '';

const localPaths = {
  deporteImg: DOC_DIR + 'deporte.jpg',
  gastronomiaImg: DOC_DIR + 'gastro.jpg',
  libreriaImg: DOC_DIR + 'libreria.jpg',
  deporteVideo: DOC_DIR + 'deporte.mp4',
};

async function ensureDownloaded(uri: string, localPath: string) {
  const info = await FileSystem.getInfoAsync(localPath);
  if (!info.exists) {
    await FileSystem.downloadAsync(uri, localPath);
  }
  return localPath;
}

export default function App() {
  const [ready, setReady] = useState(false);
  const [localImagePaths, setLocalImagePaths] = useState<{ [k: string]: string }>({});
  const [localVideoPath, setLocalVideoPath] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      try {
        // Descargar imágenes y video a local (primera vez)
        const deporteImg = await ensureDownloaded(REMOTE_IMAGES.deporte, localPaths.deporteImg);
        const gastroImg = await ensureDownloaded(REMOTE_IMAGES.gastronomia, localPaths.gastronomiaImg);
        const libreriaImg = await ensureDownloaded(REMOTE_IMAGES.libreria, localPaths.libreriaImg);
        const deporteVid = await ensureDownloaded(REMOTE_VIDEO_MP4, localPaths.deporteVideo);

        setLocalImagePaths({
          deporte: deporteImg,
          gastronomia: gastroImg,
          libreria: libreriaImg,
        });
        setLocalVideoPath(deporteVid);

        // Configuración de Audio (requerido por expo-av en Android para video)
        await Audio.setAudioModeAsync({
          allowsRecordingIOS: false,
          playsInSilentModeIOS: true,
          staysActiveInBackground: false,
          shouldDuckAndroid: true,
          playThroughEarpieceAndroid: false,
        });

        setReady(true);
      } catch (e: any) {
        console.error(e);
        Alert.alert('Error', 'No se pudieron preparar los archivos. Revisa tu conexión de internet.');
      }
    })();
  }, []);

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <Text style={styles.title}>Expo Media App — Deporte, Gastronomía y Librería</Text>

      {!ready && (
        <View style={{ padding: 20, alignItems: 'center' }}>
          <ActivityIndicator size="large" />
          <Text style={{ color: '#fff', marginTop: 10 }}>Preparando archivos locales…</Text>
        </View>
      )}

      {ready && (
        <>
          <Text style={styles.section}>1) Imágenes locales</Text>
          <View style={styles.row}>
            <Card title="Deporte (local)">
              <Image source={{ uri: localImagePaths.deporte }} style={styles.image} contentFit="cover" transition={300} />
            </Card>
            <Card title="Gastronomía (local)">
              <Image source={{ uri: localImagePaths.gastronomia }} style={styles.image} contentFit="cover" transition={300} />
            </Card>
            <Card title="Librería (local)">
              <Image source={{ uri: localImagePaths.libreria }} style={styles.image} contentFit="cover" transition={300} />
            </Card>
          </View>

          <Text style={styles.section}>2) Imágenes en línea</Text>
          <View style={styles.row}>
            <Card title="Deporte (URL)">
              <Image source={{ uri: REMOTE_IMAGES.deporte }} style={styles.image} contentFit="cover" transition={300} />
            </Card>
            <Card title="Gastronomía (URL)">
              <Image source={{ uri: REMOTE_IMAGES.gastronomia }} style={styles.image} contentFit="cover" transition={300} />
            </Card>
            <Card title="Librería (URL)">
              <Image source={{ uri: REMOTE_IMAGES.libreria }} style={styles.image} contentFit="cover" transition={300} />
            </Card>
          </View>

          <Text style={styles.section}>3) Video local (descargado a dispositivo)</Text>
          <View style={styles.row}>
            <Card title="Deporte (mp4 local)">
              {localVideoPath && (
                <Video
                  source={{ uri: localVideoPath }}
                  style={styles.video}
                  useNativeControls
                  resizeMode="contain"
                  isLooping
                />
              )}
            </Card>
          </View>

          <Text style={styles.section}>4) Video en línea</Text>
          <View style={styles.row}>
            <Card title="Demo (URL pública)">
              <Video
                source={{ uri: REMOTE_VIDEO_MP4 }}
                style={styles.video}
                useNativeControls
                resizeMode="contain"
                isLooping
              />
            </Card>
          </View>
        </>
      )}
    </ScrollView>
  );
}

function Card({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <View style={styles.card}>
      <Text style={styles.cardTitle}>{title}</Text>
      {children}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0a2a43' },
  content: { padding: 16, paddingBottom: 40 },
  title: { color: '#fff', fontSize: 20, fontWeight: '800', marginBottom: 12, textAlign: 'center' },
  section: { color: '#2bb6f6', fontSize: 16, fontWeight: '700', marginVertical: 10 },
  row: { flexDirection: 'row', flexWrap: 'wrap', gap: 12 },
  card: { backgroundColor: '#fff', borderRadius: 14, padding: 10, width: '100%', minWidth: 280, elevation: 2, marginBottom: 12 },
  cardTitle: { fontSize: 14, fontWeight: '700', marginBottom: 8, color: '#0f1226' },
  image: { width: '100%', height: 170, borderRadius: 10 },
  video: { width: '100%', height: 210, borderRadius: 10, backgroundColor: '#000' },
});
