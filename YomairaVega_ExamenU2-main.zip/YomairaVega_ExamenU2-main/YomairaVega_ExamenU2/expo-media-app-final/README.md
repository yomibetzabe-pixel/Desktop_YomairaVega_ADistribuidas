
# Expo Media App Final

**Compatibilidad:** Expo SDK 54 + React Native 0.81 + React 19.1 — Funciona en Expo Go.

## Pasos
```bash
npm install
npx expo install expo-av expo-image expo-file-system
npx expo start -c
```
